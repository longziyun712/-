a=[[0]]*2+[[0]]*2
print(a)
a[0][0]=5
print(a)

a = [1,2,3,4]
b = [1,2,3,4]
print( a == b) #>>True
print( a is b)


a=[[0]]*3
a[0].append(1)
print(a)



