s=input()
res=''
for i in s:
    if i=='0':
        res+='1'
    else:
        res+='0'
print(res)

s=input()
res=''
for i in s:
    if i=='0':
        res+='1'
    else:
        res+='0'
print(res)